SELECT REGEXP_REPLACE(LOWER(SUBSTR(INITCAP(T.COLUMN_NAME), 1, 1)) ||
                      SUBSTR(INITCAP(T.COLUMN_NAME), 2),
                      '(\w)[_]',
                      '\1') AS ������,
       CASE
         WHEN T.DATA_TYPE = 'NUMBER' AND T.DATA_SCALE = 0 THEN
          'long'
         WHEN T.DATA_TYPE = 'NUMBER' AND T.DATA_SCALE > 0 THEN
          'double'
         WHEN T.DATA_TYPE = 'VARCHAR2' or T.DATA_TYPE = 'CHAR' THEN
          'String'
         WHEN T.DATA_TYPE = 'DATE' THEN
          'Date'
         WHEN T.DATA_TYPE = 'TIMESTAMP' THEN
          'Timestamp'
       END AS ����,
       T1.COMMENTS AS ��ע,
       T.COLUMN_NAME AS ���ݿ��ֶ���
  FROM USER_TAB_COLUMNS T
  LEFT JOIN USER_COL_COMMENTS T1
    ON T.TABLE_NAME = T1.TABLE_NAME
   AND T.COLUMN_NAME = T1.COLUMN_NAME
 WHERE T.TABLE_NAME = 'TABLE_NAME';